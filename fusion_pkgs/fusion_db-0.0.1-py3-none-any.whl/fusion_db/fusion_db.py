# %%
from siuba import head, collect, rename, select, distinct
from siuba.siu.dispatchers import verb_dispatch
from siuba.sql import LazyTbl
from snowflake.sqlalchemy import URL
from sqlalchemy import create_engine
from dbcooper import DbCooper, DbcSimpleTable, AccessorHierarchyBuilder
from functools import partial
from snowflake.connector.pandas_tools import pd_writer

# %%
DB_ACCOUNT = "vu15928.canada-central.azure"

# %%


@verb_dispatch(LazyTbl)
def rename_cols_toupper(lazy_tbl):
    cols = (lazy_tbl >> head(1) >> collect()).columns.values.tolist()
    return lazy_tbl >> rename(**{str(col).upper(): col for col in cols})


# %%


def create_fusion_engine(user, password, role=None, database=None, schema=None):
    con_str = URL(
        account=DB_ACCOUNT,
        user=user,
        password=password,
        role="" if role is None else role,
        database="" if database is None else database,
        schema="" if schema is None else schema,
    )
    return create_engine(con_str)


# %%
class DbcFusionTable(DbcSimpleTable):
    def __call__(self, cols_uppercase=True, lazy=False):
        lazy_tbl = super().__call__()
        if cols_uppercase:
            lazy_tbl = lazy_tbl >> rename_cols_toupper()
        if lazy:
            return lazy_tbl
        return lazy_tbl >> collect()


# %%
class FusionDB(DbCooper):
    def __init__(
        self,
        user,
        password,
        role=None,
    ):
        engine = create_fusion_engine(user, password, role)
        self._upload_engine = partial(
            create_fusion_engine, user=user, password=password
        )
        super().__init__(
            engine=engine,
            table_factory=DbcFusionTable,
            accessor_builder=AccessorHierarchyBuilder(omit_database=False),
        )

    def upload(
        self,
        df,
        database=None,
        schema=None,
        table=None,
        role="",
        if_exists="fail",
    ):
        """
        if_exists: {'fail', 'replace', 'append'}, default 'fail'
        """
        res = df.to_sql(
            table.lower(),
            con=self._upload_engine(role=role, database=database, schema=schema),
            if_exists=if_exists,
            index=False,
            method=pd_writer,
        )
        return res
