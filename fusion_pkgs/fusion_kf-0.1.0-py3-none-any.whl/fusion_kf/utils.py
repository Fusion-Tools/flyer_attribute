from datetime import date
from dateutil.relativedelta import relativedelta

def first_day_of_previous_month():
    today = date.today()
    last_month_start = today.replace(day=1) - relativedelta(months=1)
    return last_month_start