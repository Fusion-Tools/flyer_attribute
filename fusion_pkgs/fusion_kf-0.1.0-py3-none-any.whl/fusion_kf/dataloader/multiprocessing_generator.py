from multiprocessing import Queue, Pool


# mainly adapted from : https://stackoverflow.com/questions/43078980/python-multiprocessing-with-generator
def multiprocessing_generator(num_processes, op_queue_size, input_generator, heavy_function):

    def worker_fn(input_queue, output_queue):
        while True:
            item = input_queue.get()
            if item is None:
                output_queue.put(None)
                break
        
            output_queue.put(heavy_function(item))

    input_queue = Queue()

    for item in input_generator:
        input_queue.put(item)

    for __ in range(num_processes):
        input_queue.put(None)

    output_queue = Queue(maxsize=op_queue_size)

    p = Pool(num_processes, worker_fn, initargs=(input_queue, output_queue))

    finished_processes = 0
    while True:
        line = output_queue.get()
        
        if line is None:
            finished_processes += 1
            if finished_processes == num_processes:
                p.close()
                p.join()
                break
        else:
            yield line
