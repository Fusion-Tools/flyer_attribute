import pandas as pd
from fusion_kf.utils import first_day_of_previous_month
from fusion_kf.dataloader.multiprocessing_generator import multiprocessing_generator
import os


class DataLoader:
    def __init__(
        self, *, table, id_cols, date_col, var_cols=None, min_date=None, max_date=None
    ):
        if isinstance(table, pd.DataFrame):
            table_type = "pd_dataframe"
        else:
            raise ValueError("Table type must be a pandas DataFrame")

        self.table_type = table_type
        self.table = table
        self.id_cols = id_cols
        self.date_col = date_col
        self.var_cols = [] if var_cols is None else var_cols
        self.min_date = None if min_date is None else min_date
        self.max_date = first_day_of_previous_month() if max_date is None else max_date

    def _reshape_to_wide(self, df):
        df = (
            df
            # .set_index(self.id_cols + [self.date_col] + self.var_cols)
            .unstack(self.var_cols)
            .sort_index(axis=1)
            .rename_axis(columns=["VALUE_COLS"] + self.var_cols)
        )
        return df

    def _complete_timeseries(self, df):
        dates = df.index.get_level_values(self.date_col)
        full_date_range = pd.date_range(
            dates.min() if not self.min_date else self.min_date,
            self.max_date,
            freq="MS",
        ).date
        # .date converts the DatetimeIndex index into Index containing date value objects

        complete_multi_index = pd.MultiIndex.from_product(
            [df.index.get_level_values(col).unique() for col in self.id_cols]
            + [full_date_range],
            names=self.id_cols + [self.date_col],
        )
        df = df.reindex(complete_multi_index)

        return df

    def format_partition(self, partition):
        partition = self._reshape_to_wide(partition)
        partition = self._complete_timeseries(partition)
        return partition

    def __iter__(self):
        for id, partition in self.table.set_index(
            self.id_cols + [self.date_col] + self.var_cols
        ).groupby(level=self.id_cols):
            yield self.format_partition(partition)

    def partitions(self, num_workers=os.cpu_count() // 4, op_queue_size=os.cpu_count() * 4):
        partitions = []
        for id, partition in self.table.set_index(
            self.id_cols + [self.date_col] + self.var_cols
        ).groupby(level=self.id_cols):
            partitions.append(partition)

        yield from multiprocessing_generator(
            num_workers,
            op_queue_size,
            partitions,
            self.format_partition
        )


# %%
