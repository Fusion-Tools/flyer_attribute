# %%
from abc import ABC, abstractmethod
from filterpy.kalman import KalmanFilter
import numpy as np
import pandas as pd


# %%
class KFModule(ABC):
    def __init__(self, *, metric_col, output_col_prefix=None):
        self.metric_col = metric_col
        self.output_col_prefix = (
            metric_col if output_col_prefix is None else output_col_prefix
        )
        self.output_cols = [
            self.output_col_prefix + "_KF",
            self.output_col_prefix + "_RTS",
        ]

    def __call__(self, raw_df):
        Q = self.process_covariance(raw_df)

        zs = raw_df.loc[:, [self.metric_col]].to_numpy(copy=True)
        zs[np.isnan(zs)] = 0

        Rs = self.measurement_covariance(raw_df)

        xs_kf, xs_rts = self._run_filter(Q, zs, Rs)
        output_df = self._attach_modelled_output(raw_df, xs_kf, xs_rts)

        return output_df

    @abstractmethod
    def process_covariance(self, raw_df):
        """
        construct and return full process covarince matrix as a numpy array
        """
        pass

    @abstractmethod
    def measurement_covariance(self, raw_df):
        """
        construct and return full measurement covarince matrix as a numpy array
        """
        pass

    @staticmethod
    def _run_filter(Q, zs, Rs):
        dim_z = zs.shape[-1]

        kf = KalmanFilter(dim_x=dim_z, dim_z=dim_z)
        kf.x = zs[0]
        kf.F = np.eye(dim_z)
        kf.H = np.eye(dim_z)
        kf.P[:] = Rs[0]
        kf.Q = Q

        xs_kf, Ps_kf, _, _ = kf.batch_filter(zs=zs, Rs=Rs)
        xs_rts, Ps_rts, _, _ = kf.rts_smoother(xs_kf, Ps_kf)
        return xs_kf, xs_rts

    def _attach_modelled_output(self, raw_df, xs_kf, xs_rts):
        col_index = raw_df.loc[:, [self.metric_col]].columns

        if col_index.nlevels > 1:
            new_col_index = pd.MultiIndex.from_product(
                [self.output_cols, raw_df[self.metric_col].columns.unique()],
                names=["VALUE_COLS"] + raw_df[self.metric_col].columns.names,
            )
        else:
            new_col_index = pd.Index(
                self.output_cols,
                name="VALUE_COLS",
            )

        modelled_df = pd.DataFrame(
            np.hstack([xs_kf, xs_rts]), columns=new_col_index, index=raw_df.index
        )
        output_df = raw_df.join(modelled_df)
        return output_df
