# %%
from fusion_kf.callbacks.callback import Callback
import pandas as pd

class ConcactPartitions(Callback):
    def on_run_end(self, models, partitions) -> None:
        return pd.concat(partitions).reset_index(drop=True)