def _call_callback_hooks(callbacks, hook_name, models, output, *args, **kwargs):
    for callback in callbacks:
        fn = getattr(callback, hook_name)
        if callable(fn):
            output = fn(models, output, *args, **kwargs)

    return output