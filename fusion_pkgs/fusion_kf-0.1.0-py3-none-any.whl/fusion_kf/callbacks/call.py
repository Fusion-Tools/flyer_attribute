def _call_callback_hooks(callbacks, hook_name, obj, output, *args, **kwargs):
    for callback in callbacks:
        fn = getattr(callback, hook_name)
        if callable(fn):
            output = fn(obj, output, *args, **kwargs)

    return output