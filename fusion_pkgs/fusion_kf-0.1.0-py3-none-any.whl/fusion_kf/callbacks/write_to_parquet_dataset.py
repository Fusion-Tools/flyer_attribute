
# %%
from fusion_kf.callbacks.callback import Callback 
import pyarrow as pa
import pyarrow.parquet as pq

# %%
class WriteToParquetDataset(Callback):
    def __init__(self, filepath, partition_cols):
        self.filepath = filepath
        self.partition_cols = partition_cols

    def on_model_partition_end(self, models, partition) -> None:
        partition_tbl = pa.Table.from_pandas(partition)
        # Local dataset write
        pq.write_to_dataset(
            partition_tbl,
            root_path=self.filepath,
            partition_cols=self.partition_cols,
        )
        return partition