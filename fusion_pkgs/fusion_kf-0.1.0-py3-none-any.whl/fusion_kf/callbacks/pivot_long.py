# %%
from fusion_kf.callbacks.callback import Callback 


# %%
class PivotLong(Callback):
    def on_model_partition_end(self, models, partition) -> None:
        return partition.stack(partition.columns.names[1:]).reset_index()