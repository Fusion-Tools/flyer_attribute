r"""
Base class used to build new callbacks.

"""

from typing import Any, Dict


class Callback:
    r"""
    Abstract base class used to build new callbacks.

    Subclass this class and override any of the relevant hooks
    """

    @property
    def state_key(self) -> str:
        return self.__class__.__qualname__

    def _generate_state_key(self, **kwargs: Any) -> str:
        return f"{self.__class__.__qualname__}{repr(kwargs)}"

    def setup(self, models, *args) -> None:
        pass

    def teardown(self, models, *args) -> None:
        pass

    def on_run_start(self, models, *args) -> None:
        """Called when run begins."""

    def on_run_end(self, models, partitions) -> None:
        """Called when run ends."""
        return partitions

    def on_model_partition_start(self, models, partition):
        """Called when the model partition begins."""
        return partition

    def on_model_partition_end(self, models, partition) -> None:
        """Called when model partition ends."""
        return partition

    def on_exception(self, models, exception: BaseException) -> None:
        pass

    def state_dict(self) -> Dict[str, Any]:
        return {}

    def load_state_dict(self, state_dict: Dict[str, Any]) -> None:
        pass

    def on_save_checkpoint(self, models, checkpoint: Dict[str, Any]) -> None:
        pass

    def on_load_checkpoint(self, models, checkpoint: Dict[str, Any]) -> None:
        pass

