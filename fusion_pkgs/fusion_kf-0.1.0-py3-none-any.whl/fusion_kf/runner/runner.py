# %%
from fusion_kf.runner.status_enum import RunnerStatus
from fusion_kf.callbacks.call import _call_callback_hooks
from fusion_kf.kf_modules import KFModule
from fusion_kf.dataloader import DataLoader
from itertools import chain
from concurrent.futures import ProcessPoolExecutor, as_completed
from threadpoolctl import threadpool_limits
import os


# %%
class Runner:
    def __init__(self, *, callbacks=None):
        self.status = RunnerStatus.INITIALIZING
        self.callbacks = callbacks if callbacks is not None else []

    def _setup(
        self, models, dataloaders, parallel, num_cpus, threads_per_partition, ckpt_path
    ):
        # if only received a model, wrap it in a list
        if isinstance(models, KFModule):
            models = [models]

        # if only received a dataloader, wrap it in a list
        if isinstance(dataloaders, DataLoader):
            dataloaders = [dataloaders]

        if parallel:
            # start ray
            # if ray.is_initialized():
            #     ray.shutdown()
            # ray.init(num_cpus=16)
            # # setup models and dataloader to run on ray
            # self.models = ray.put(models)
            self.models = models
            self.dataloader = chain.from_iterable(
                [dl.partitions() for dl in dataloaders]
            )
        else:
            self.models = models
            self.dataloader = chain.from_iterable(dataloaders)

    def _teardown(self):
        pass
        # ray.shutdown()

    def run(
        self,
        *,
        models,
        dataloaders,
        parallel=True,
        num_cpus=os.cpu_count(),
        threads_per_partition=1,
        ckpt_path=None
    ):
        try:
            return self._run_impl(
                models,
                dataloaders,
                parallel,
                num_cpus,
                threads_per_partition,
                ckpt_path,
            )

        except KeyboardInterrupt as exception:
            print("Detected KeyboardInterrupt, attempting graceful shutdown...")
            # user could press Ctrl+c many times... only shutdown once
            if self.status != RunnerStatus.INTERRUPTED:
                self.status = RunnerStatus.INTERRUPTED
                _call_callback_hooks(self.callbacks, "on_exception", self, exception)
                self._teardown()

        except BaseException as exception:
            self.status = RunnerStatus.INTERRUPTED
            _call_callback_hooks(self.callbacks, "on_exception", self, exception)
            self._teardown()
            raise

    def _run_impl(
        self, models, dataloaders, parallel, num_cpus, threads_per_partition, ckpt_path
    ):
        self.status = RunnerStatus.RUNNING

        # ----------------------------
        # SET UP THE RUNNER
        # ----------------------------

        self._setup(
            models, dataloaders, parallel, num_cpus, threads_per_partition, ckpt_path
        )
        _call_callback_hooks(self.callbacks, "setup", self, None)
        _call_callback_hooks(self.callbacks, "on_run_start", self, None)

        # ----------------------------
        # RUN THE RUNNER
        # ----------------------------
        if parallel:
            results = self._run_partition_loop_parallel(num_cpus, threads_per_partition)
        else:
            results = self._run_partition_loop()

        # ----------------------------
        # POST-Running CLEAN UP
        # ----------------------------

        results = _call_callback_hooks(self.callbacks, "on_run_end", self, results)
        _call_callback_hooks(self.callbacks, "teardown", self, None)
        self._teardown()

        self.status = RunnerStatus.FINISHED

        return results

    def _run_partition_loop(self):
        outputs = [
            _run_partition(self.models, partition, self.callbacks)
            for partition in self.dataloader
        ]
        return outputs

    def _run_partition_loop_parallel(self, num_cpus, threads_per_partition):
        with threadpool_limits(limits=threads_per_partition, user_api="blas"):
            with ProcessPoolExecutor(-(num_cpus // -threads_per_partition)) as executor:
                futures = [
                    executor.submit(
                        _run_partition, self.models, partition, self.callbacks
                    )
                    for partition in self.dataloader
                ]

        return [f.result() for f in as_completed(futures)]


# %%


def _run_partition(models, partition, callbacks):
    partition = _call_callback_hooks(callbacks, "on_model_partition_start", models, partition)  # fmt: skip

    # apply all the models in a sequence to the partition
    output = partition
    for model in models:
        output = model(output)

    output = _call_callback_hooks(callbacks, "on_model_partition_end", models, output)
    return output
